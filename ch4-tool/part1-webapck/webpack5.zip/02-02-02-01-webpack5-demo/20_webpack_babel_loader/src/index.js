const title = '前端'
const foo = () => {
  console.log(title)
}

foo()


/**
 * babel-loader 相关的配置文件 
 * babel.config.js(json cjs mjs)
 * babelrc.json(js)
 */