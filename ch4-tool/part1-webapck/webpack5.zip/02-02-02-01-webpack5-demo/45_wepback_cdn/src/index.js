import _ from 'lodash'

console.log('index.js')
console.log(_.join(['前端', '开发']))
 

