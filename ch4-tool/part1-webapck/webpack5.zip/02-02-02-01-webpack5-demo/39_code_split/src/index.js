import 'jquery'

console.log('index.js代码')