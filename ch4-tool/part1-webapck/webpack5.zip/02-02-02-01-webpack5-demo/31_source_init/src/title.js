module.exports = 'aa'

console.log('title.js模块')

console.log(aa)

// source-map 映射--》在调试的时候可以定位到源代码中的信息 

